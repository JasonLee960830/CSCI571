//
//  Artist2ImageCollectionView.swift
//  yunze_hw9
//
//  Created by  jasonlee on 2018/11/28.
//  Copyright © 2018 yunze li. All rights reserved.
//

import UIKit

class Artist2ImageCollectionView: UICollectionView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
