//
//  ArtistImageCollectionViewCell.swift
//  yunze_hw9
//
//  Created by  jasonlee on 2018/11/25.
//  Copyright © 2018 yunze li. All rights reserved.
//

import UIKit

class ArtistImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var artistImage: UIImageView!
}
